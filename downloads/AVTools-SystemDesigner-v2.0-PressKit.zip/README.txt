﻿AVTools System Designer v2.0 ΓÇö Press Kit
J. Stevens BIM Acoustics | April 21, 2026
CONTENTS
  AVTools-SystemDesigner-v2.0-PressRelease.rtf
    Formatted press release (opens in Microsoft Word).
    Can be saved as .docx from Word if preferred.
  AVTools-SystemDesigner-v2.0-PressRelease.txt
    Plain-text press release (for direct pasting into CMS).
  screenshots/
    High-resolution screenshots from the v2.0 release.
    Format: PNG, 1860 x 930 px, suitable for web and print use.
    Rooms Tab.png                  Room selection, area, volume, ceiling height
    Configuration.png              Speaker configuration and spacing
    Coverage.png                   Direct-field coverage analysis
    Coverage mapping.png           Iso-contour coverage mapping
    RT60.png                       Room acoustics calculation
    Acoustics Schedule.png         Room acoustics schedule export
    Circuiting.png                 Zone-based circuit assignment
    Loudspeaker Circuit Schedule.png  Exported circuit schedule
    Amps cabling.png               Amplifier and cabling design
    Wiring added.png               Wiring diagram in model
    Coordination.png               Interference and clash list
    Clash Detection.png            Clash detection in 3D
    Clash Detection RCP.png        Clash detection in RCP view
MEDIA CONTACT
  Jerrold Stevens
  Founder, J. Stevens BIM Acoustics
  info@bimacoustics.net
  +1 (504) 401-4983
  https://www.bimacoustics.net
LICENSE
  Screenshots may be used in editorial coverage of AVTools System Designer
  with attribution to J. Stevens BIM Acoustics. No modification beyond
  standard cropping/resizing for layout. Contact for other uses.
